Thanks for downloading vibranceGUI!

----------------------------------------------------------------------------------------------------

For Help, Troubleshooting and Q&A see the Steam Guide: https://vibrancegui.com/vibrance/guide 
If the Guide did not help you to fix your problem, contact me on Twitter: https://twitter.com/juvlarN